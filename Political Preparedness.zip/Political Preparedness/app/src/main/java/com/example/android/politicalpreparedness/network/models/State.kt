package com.example.android.politicalpreparedness.network.models

data class State (
    val name: String,
    val electionAdministrationBody: AdministrationBody
)